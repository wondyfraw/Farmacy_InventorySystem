<?php 

$lang["login_gcaptcha"] = "";
$lang["login_go"] = "GOOOO";
$lang["login_invalid_gcaptcha"] = "";
$lang["login_invalid_installation"] = "";
$lang["login_invalid_username_and_password"] = "ชื่อผู้ใช้/รหัส ไม่ถูกต้อง";
$lang["login_login"] = "ลงชื่อเข้าใช้";
$lang["login_password"] = "รหัสผ่าน";
$lang["login_username"] = "ชื่อผู้ใช้";
