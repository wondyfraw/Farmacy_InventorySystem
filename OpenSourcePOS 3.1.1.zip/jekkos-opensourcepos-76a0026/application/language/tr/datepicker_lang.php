<?php 

$lang["datepicker_all_time"] = "Tüm Zamanlar";
$lang["datepicker_apply"] = "Uygula";
$lang["datepicker_cancel"] = "İptal Et";
$lang["datepicker_custom"] = "Özel";
$lang["datepicker_from"] = "Şundan";
$lang["datepicker_last_30"] = "Son 30 Gün";
$lang["datepicker_last_7"] = "Son 7 Gün";
$lang["datepicker_last_financial_year"] = "";
$lang["datepicker_last_month"] = "Geçen Ay";
$lang["datepicker_last_year"] = "Geçen Yıl";
$lang["datepicker_same_month_last_year"] = "Geçen Sene Aynı Ay";
$lang["datepicker_same_month_to_same_day_last_year"] = "Geçen Sene Aynı Aydan Aynı Güne";
$lang["datepicker_this_financial_year"] = "";
$lang["datepicker_this_month"] = "Bu Ay";
$lang["datepicker_this_year"] = "Bu Yıl";
$lang["datepicker_to"] = "Şuna";
$lang["datepicker_today"] = "Bugün";
$lang["datepicker_today_last_year"] = "Geçen Yıl Bugün";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Dün";
