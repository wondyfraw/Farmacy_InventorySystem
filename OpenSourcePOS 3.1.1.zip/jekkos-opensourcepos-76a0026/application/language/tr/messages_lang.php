<?php 

$lang["messages_first_name"] = "İsim";
$lang["messages_last_name"] = "Soyisim";
$lang["messages_message"] = "Mesaj";
$lang["messages_message_placeholder"] = "Mesajınız...";
$lang["messages_message_required"] = "Mesaj giriniz";
$lang["messages_multiple_phones"] = "(Birden fazla alıcı için telefon numaralarını virgül ile ayırınız)";
$lang["messages_phone"] = "Telefon Numarası";
$lang["messages_phone_number_required"] = "Telefon numarası giriniz";
$lang["messages_phone_placeholder"] = "Mobil numaralar...";
$lang["messages_sms_send"] = "SMS Gönder";
$lang["messages_successfully_sent"] = "Mesaj başarıyla gönderildi : ";
$lang["messages_unsuccessfully_sent"] = "Mesaj gönderilemedi. Alıcı : ";
