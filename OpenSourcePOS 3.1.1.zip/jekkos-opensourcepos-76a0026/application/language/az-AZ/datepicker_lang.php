<?php 

$lang["datepicker_all_time"] = "All Time";
$lang["datepicker_apply"] = "Apply";
$lang["datepicker_cancel"] = "Cancel";
$lang["datepicker_custom"] = "Custom";
$lang["datepicker_from"] = "From";
$lang["datepicker_last_30"] = "Last 30 Days";
$lang["datepicker_last_7"] = "Last 7 Days";
$lang["datepicker_last_financial_year"] = "Last Financial Year";
$lang["datepicker_last_month"] = "Last Month";
$lang["datepicker_last_year"] = "Last Year";
$lang["datepicker_same_month_last_year"] = "Same Month Last Year";
$lang["datepicker_same_month_to_same_day_last_year"] = "Same Month To Same Day Last Year";
$lang["datepicker_this_financial_year"] = "This Financial Year";
$lang["datepicker_this_month"] = "This Month";
$lang["datepicker_this_year"] = "This Year";
$lang["datepicker_to"] = "To";
$lang["datepicker_today"] = "Today";
$lang["datepicker_today_last_year"] = "Today Last Year";
$lang["datepicker_weekstart"] = "0";
$lang["datepicker_yesterday"] = "Yesterday";
